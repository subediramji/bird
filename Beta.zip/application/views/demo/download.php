<div class="titlebar">
       <h1 class="titlebarHeading">Downloads</h1> 
</div>
<div style="background-color: #26ab07; color: #fff; height: 200px; padding: 2% 5% 2% 5%;">
    <h3 style="margin: 0; padding: 10px;">Download latest version of BnW</h3> 
</div>