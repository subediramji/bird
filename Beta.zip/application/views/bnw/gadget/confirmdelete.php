<div class="rightSide">
<div>
    <h1>
       Are you sure want to delete this page ?
    </h1>
    <input type="button" value="yes"/><input type="button" value="Cancel"/>
</div>
</div>
<div class="clear"></div>
</div>